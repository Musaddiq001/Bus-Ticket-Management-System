<!DOCTYPE HTML>
<html>

<head>
  <title>Log in page</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="{{asset('website/style/style.css')}}" />
</head>

<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
	<h1>Welcome to Bus Ticket Management System</h1>
	<h2>Log in</h2>
	        </div>
      </div>
	<form method="post" >
		@csrf
<!-- 		{{csrf_field()}} -->		
<!-- 		<input type="hidden" name="_token" value="{{csrf_token()}}"> -->

<div id="content_header"></div>
    <div id="site_content">
      <div id="banner"></div>
	  <div id="sidebar_container">
        
        <div class="sidebar">
     
        </div>
        
      </div>
      <div id="content">

        Usertype:
				<select name="usertype">
				<option value="admin">admin</option>
				<option value="manager">manager</option>
				
				</select> <br>
        
		Username:  <input type="text" required name="uname" > <br>
		Password: <input type="password" required name="password" ><br>
		<input type="submit" name="submit" value="login" ><br> <br>
</div>
    </div>
      <div id="footer">
    
  <h3 style="color: red;">{{session('msg')}} </h3>
      </div> 
    </div>
  </div>
</body>
</html>
