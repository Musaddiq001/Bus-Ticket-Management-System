<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Bus List</h1>&nbsp
	<a href="<?php echo e(route('home.index')); ?>">back</a> |
	<a href="/logout">Logout</a>  <br> <br>

	<form method="get" action="<?php echo e(route('search')); ?>">
	<?php echo csrf_field(); ?>
	Search Buses: <input type="search" name="search" >
		<input type="submit" name="submit" value="Search" ><br> <br> 
		Search Buses By Operator : 

		<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search by Operator" title="Type Operator Name">

		</form>

		<table id="myTable" border="1">
		<tr>
			<th>ID</th>
			<th>OPERATOR</th>
			<th>MANAGER</th>
			<th>NAME</th>
			<th>lOCATION</th>
			<th>SEAT ROW</th>
			<th>SEAT COLUMN</th>
			<th>ACTION</th>
		</tr>
		
		<?php $__currentLoopData = $buses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($user['userId']); ?></td>
			<td><?php echo e($user['operator']); ?></td>
			<td><?php echo e($user['manager']); ?></td>
			<td><?php echo e($user['name']); ?></td>
			<td><?php echo e($user['location']); ?></td>
			<td><?php echo e($user['seatRow']); ?></td>
			<td><?php echo e($user['seatColumn']); ?></td>
			<td>
				<a href="<?php echo e(route('home.delete', $user['userId'])); ?>">Delete</a> |
				<a href="<?php echo e(route('home.edit1', $user['userId'])); ?>">Edit</a> 
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

	<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\aaaa\btrs\resources\views/home/view_buses.blade.php ENDPATH**/ ?>