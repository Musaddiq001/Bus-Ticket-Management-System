-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2020 at 01:34 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `buscounters`
--

CREATE TABLE `buscounters` (
  `userId` int(20) NOT NULL,
  `operator` varchar(256) NOT NULL,
  `manager` varchar(256) NOT NULL,
  `name` varchar(256) NOT NULL,
  `location` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buscounters`
--

INSERT INTO `buscounters` (`userId`, `operator`, `manager`, `name`, `location`) VALUES
(1, 'SHOHAGH', 'MR. AB', 'Elite', 'DHK-CTG'),
(2, 'Green Line', 'Mr. C', 'double decker', 'Ctg-Dhk'),
(3, 'Hanif', 'MR. K', 'non - ac', 'CTg-DHK'),
(4, 'Shyamoli', 'manager', 'ac', 'ctg'),
(5, 'ena', 'Musa', 'non-ac', 'ctg');

-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

CREATE TABLE `buses` (
  `userId` int(20) NOT NULL,
  `operator` varchar(256) NOT NULL,
  `manager` varchar(256) NOT NULL,
  `name` varchar(256) NOT NULL,
  `location` varchar(256) NOT NULL,
  `seatRow` int(20) NOT NULL,
  `seatColumn` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`userId`, `operator`, `manager`, `name`, `location`, `seatRow`, `seatColumn`) VALUES
(1, 'Shohagh', 'Manager', 'Elite', 'Dhaka', 10, 3),
(2, 'Green Line', 'Musa', 'Double Deck', 'CTG', 11, 3),
(3, 'Shyamoli', 'Manager', 'Hyundai', 'Dhaka', 10, 4),
(4, 'Silk Line', 'Musa', 'Volvo', 'CTG', 10, 4),
(5, 'Saint martin', 'admin', 'AC', 'ctg', 10, 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `username` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `type` varchar(20) NOT NULL,
  `registered` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `username`, `email`, `password`, `type`, `registered`) VALUES
(1, 'admin', 'admin@gmail.com', '1234', 'admin', 'yes'),
(2, 'manager', 'manager@gmail.com', '1234', 'manager', 'yes'),
(3, 'abc', 'abc@gmail.com', '1234', 'manager', 'yes'),
(8, 'new', 'new@gmail.com', '1234', 'staff', 'yes'),
(9, 'Musa', 'musa@gmail.com', '1234', 'manager', 'yes'),
(10, 'musaddiq001', 'mak@gmail.com', '1234', 'manager', 'yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buscounters`
--
ALTER TABLE `buscounters`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `buses`
--
ALTER TABLE `buses`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buscounters`
--
ALTER TABLE `buscounters`
  MODIFY `userId` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `buses`
--
ALTER TABLE `buses`
  MODIFY `userId` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
