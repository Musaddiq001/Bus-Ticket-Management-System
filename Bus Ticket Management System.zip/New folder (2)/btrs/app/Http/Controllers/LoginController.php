<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;

class LoginController extends Controller
{
    
    public function index(Request $req){
    	return view('login.index');
    }

    public function verify(Request $req){

/*        $user = User::where('username', $req->uname)
                    ->where('password', $req->password)
                    ->first();

        $user = DB::table('users')
                    ->where('username', $req->uname)
                    ->where('password', $req->password)
                    ->first();
					*/
					
            if($req->usertype=='admin'){
				$user = User::where('username', $req->uname)
                    ->where('password', $req->password)
					->where('type', $req->usertype)
                    ->first();
					if($user!=null){
            $req->session()->put('uname', $req->uname);
    		return redirect()->route('home.index');
            }
			else
				{
            $req->session()->flash('msg', 'invalid username/password');
    		
            return redirect('/login'); 
    	}
			}
            else if($req->usertype=='manager'){
             $user = User::where('username', $req->uname)
                    ->where('password', $req->password)
					->where('type', $req->usertype)
                    ->first();
					if($user!=null){
            $req->session()->put('uname', $req->uname);
    		return redirect()->route('manager.managerindex');
            }
			else
				{
            $req->session()->flash('msg', 'invalid username/password');
            return redirect('/login'); 
    	}
               
            
            }
    	
		else{
            $req->session()->flash('msg', 'invalid username/password');
    	
            return redirect('/login'); 
    	}
    }
}
