<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Create Bus service</h1>&nbsp
	<a href="<?php echo e(route('home.index')); ?>">Back</a> |
	<a href="<?php echo e(route('logout')); ?>">Logout</a> 

	<form method="post" enctype="multipart/form-data">
		<?php echo e(csrf_field()); ?>

		<table>
			<tr>
				<td>Operator</td>
				<td><input type="text" name="operator" value="<?php echo e(old('operator')); ?>"></td>
			</tr>
			<tr>
				<td>Manager</td>
				<td><input type="text" name="manager" value="<?php echo e(old('manager')); ?>"></td>
			</tr>
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" value="<?php echo e(old('name')); ?>"></td>
			</tr>
			<tr>
				<td>Location</td>
				<td><input type="text" name="location" value="<?php echo e(old('location')); ?>"></td>
			</tr>
			<tr>
				<td>Seat Row</td>
				<td><input type="text" name="seatRow" value="<?php echo e(old('seatRow')); ?>"></td>
			</tr>
			<tr>
				<td>Seat Column</td>
				<<td><input type="text" name="seatColumn" value="<?php echo e(old('seatColumn')); ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Create"></td>
			</tr>
		</table>
	</form>
	
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($err); ?> <br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\aaaa\btrs\resources\views/home/add.blade.php ENDPATH**/ ?>