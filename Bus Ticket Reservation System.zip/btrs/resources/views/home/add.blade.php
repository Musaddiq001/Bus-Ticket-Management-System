<!DOCTYPE HTML>
<html>

<head>
  <title>Add New Bus</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="{{asset('website/style/style.css')}}" />
</head>
<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
		<h1>Welcome Bus Ticket Management System</h1>
          <h2>Add new bus</h2>
        </div>
      </div>&nbsp
<div id="menubar">
        <ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li class="selected"><a href="{{route('home.list')}}">View Managers</a></li>
	<li class="selected"><a href="{{route('home.list1')}}">View Support Staff</a></li>
	<li class="selected"><a href="{{route('home.list2')}}">View Bus Counters</a></li>
	<li class="selected"><a href="{{route('home.list3')}}">View Buses list</a></li>
	<li class="selected"><a href="{{route('home.add')}}">Add new bus</a></li>
	
	<li class="selected"><a href="{{route('logout')}}">Logout</a></li>
		  
        </ul>
      </div>

	<form method="post" enctype="multipart/form-data">
		{{csrf_field()}}
		
			<div id="site_content">

		<div id="content">
		<table>
			<tr>
				<td>Operator</td>
				<td><input type="text" name="operator" value="{{old('operator')}}"></td>
			</tr>
			<tr>
				<td>Manager</td>
				<td><input type="text" name="manager" value="{{old('manager')}}"></td>
			</tr>
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" value="{{old('name')}}"></td>
			</tr>
			<tr>
				<td>Location</td>
				<td><input type="text" name="location" value="{{old('location')}}"></td>
			</tr>
			<tr>
				<td>Seat Row</td>
				<td><input type="text" name="seatRow" value="{{old('seatRow')}}"></td>
			</tr>
			<tr>
				<td>Seat Column</td>
				<<td><input type="text" name="seatColumn" value="{{old('seatColumn')}}"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Create"></td>
			</tr>
		</table>
	</div> 
	  <div id="sidebar">
    
  <h3 style="color: red;">@foreach($errors->all() as $err)
		{{$err}} <br>
	@endforeach </h3>
	</div>
		
		</div>
    </div>
	</form>

</body>
</html>