<!DOCTYPE HTML>
<html>

<head>
  <title>Manager Home Page</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/style/style.css')); ?>" />
</head>
<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
	<h1>Welcome Bus Ticket Management System</h1>
	<h2>Manager Home Page</h2>
        </div>
      </div>&nbsp
	  
	  <div id="menubar">
        <ul id="menu">

	<li class="selected"><a href="<?php echo e(route('manager.list4')); ?>">View All</a></li>	
	<li class="selected"><a href="<?php echo e(route('logout')); ?>">Logout</a></li>

        </ul>
      </div>
	  <div id="site_content">
	  
	  <div id="footer">
      </div>
	  
	  </div>
	</form>

	
	
      </div>
    </div>

</body>
</html>

</body>
</html><?php /**PATH C:\xampp\htdocs\aaaa\assignment\btrs\resources\views/manager/managerindex.blade.php ENDPATH**/ ?>