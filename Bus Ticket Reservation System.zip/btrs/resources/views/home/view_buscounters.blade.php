<!DOCTYPE HTML>
<html>

<head>
  <title>Bus Counters</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="{{asset('website/style/style.css')}}" />
</head>
<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
		<h1>Welcome Bus Ticket Management System!</h1>
		<h2>Bus Counters</h2>
        </div>
      </div>&nbsp
	  
	  <div id="menubar">
        <ul id="menu">
<li class="selected"><a href="{{route('home.list')}}">View Managers</a></li>
	<li class="selected"><a href="{{route('home.list1')}}">View Support Staff</a></li>
	<li class="selected"><a href="{{route('home.list2')}}">View Bus Counters</a></li>
	<li class="selected"><a href="{{route('home.list3')}}">View Buses list</a></li>
	<li class="selected"><a href="{{route('home.add')}}">Add new bus</a></li>
	
	<li class="selected"><a href="{{route('logout')}}">Logout</a></li>

        </ul>
      </div>
	  <div id="site_content">
	  <div class="sidebar">
	  Search Bus counters By ID : 

		<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search by name" title="Type Name">
	  </div>
	  <div id="content">

	<form method="get" action="{{ route('searchCounter') }}">
	@csrf
	Search Bus Counters: <input type="search" name="search" >
		<input type="submit" name="submit" value="Search" ><br> <br> 
		</form>

	<table id="myTable" border="1">
		<tr>
			<th>ID</th>
			<th>OPERATOR</th>
			<th>MANAGER</th>
			<th>NAME</th>
			<th>lOCATION</th>
			<th>ACTION</th>
		</tr>
		
		@foreach($buscounters as $user)
		<tr>
			<td>{{$user['userId']}}</td>
			<td>{{$user['operator']}}</td>
			<td>{{$user['manager']}}</td>
			<td>{{$user['name']}}</td>
			<td>{{$user['location']}}</td>
			<td>
				<a href="#">Delete</a> |
				<a href="#">Edit</a> 
			</td>
		</tr>
		@endforeach
	</table>
	
		</div>
    </div>

	<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[3];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</body>
</html>