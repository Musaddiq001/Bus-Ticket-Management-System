<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Manager Home page! Welcome to BTMS!</h1>&nbsp

	<a href="<?php echo e(route('manager.list4')); ?>">View All</a> |
	<a href="/logout">Logout</a> 

</body>
</html><?php /**PATH C:\xampp\htdocs\aaaa\btrs\resources\views/manager/managerindex.blade.php ENDPATH**/ ?>