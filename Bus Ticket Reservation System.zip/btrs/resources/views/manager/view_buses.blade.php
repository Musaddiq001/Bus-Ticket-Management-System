<!DOCTYPE HTML>
<html>

<head>
  <title>Bus List and managers details</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="{{asset('website/style/style.css')}}" />
</head>
<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
	<h1>Welcome Bus Ticket Management System!</h1>
	<h2>Bus List and managers details</h2>&nbsp
	<div id="menubar">
        <ul id="menu">

	<li class="selected"><a href="{{route('manager.list4')}}">View All</a></li>	
	<li class="selected"><a href="{{route('logout')}}">Logout</a></li>

        </ul>
      </div>

	<table border="1">
		<tr>
			<th>ID</th>
			<th>OPERATOR</th>
			<th>MANAGER</th>
			<th>NAME</th>
			<th>lOCATION</th>
			<th>SEAT ROW</th>
			<th>SEAT COLUMN</th>
			<th>ACTION</th>
		</tr>
		
		@foreach($buses as $user)
		<tr>
			<td>{{$user['userId']}}</td>
			<td>{{$user['operator']}}</td>
			<td>{{$user['manager']}}</td>
			<td>{{$user['name']}}</td>
			<td>{{$user['location']}}</td>
			<td>{{$user['seatRow']}}</td>
			<td>{{$user['seatColumn']}}</td>
			<td>
				<a href="#">Delete</a> |
				<a href="#">Edit</a> 
			</td>
		</tr>
		@endforeach
	</table>
	</div>
    </div>

</body>
</html>