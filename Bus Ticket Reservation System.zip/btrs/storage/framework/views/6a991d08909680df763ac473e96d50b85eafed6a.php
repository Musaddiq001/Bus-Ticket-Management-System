<!DOCTYPE HTML>
<html>

<head>
  <title>Support Staffs</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/style/style.css')); ?>" />
</head>
<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
		<h1>Welcome Bus Ticket Management System!</h1>
          <h2>Bus Support Staffs List</h2>
        </div>
      </div>&nbsp
	<div id="menubar">
        <ul id="menu">
<li class="selected"><a href="<?php echo e(route('home.list')); ?>">View Managers</a></li>
	<li class="selected"><a href="<?php echo e(route('home.list1')); ?>">View Support Staff</a></li>
	<li class="selected"><a href="<?php echo e(route('home.list2')); ?>">View Bus Counters</a></li>
	<li class="selected"><a href="<?php echo e(route('home.list3')); ?>">View Buses list</a></li>
	<li class="selected"><a href="<?php echo e(route('home.add')); ?>">Add new bus</a></li>
	
	<li class="selected"><a href="<?php echo e(route('logout')); ?>">Logout</a></li>

        </ul>
      </div>
	  <div id="site_content">
	  
	  <div id="content">

	<table border="1">
		<tr>
			<th>ID</th>
			<th>USERNAME</th>
			<th>EMAIL</th>
			<th>TYPE</th>
		</tr>
		
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($user['userId']); ?></td>
			<td><?php echo e($user['username']); ?></td>
			<td><?php echo e($user['email']); ?></td>
			<td><?php echo e($user['type']); ?></td>
			<td>
				<a href="<?php echo e(route('home.edit', $user['userId'])); ?>">Edit</a> | 
				<a href="<?php echo e(route('home.delete2', $user['userId'])); ?>">Delete</a> 
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

</div>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\aaaa\assignment\btrs\resources\views/home/view_staffs.blade.php ENDPATH**/ ?>