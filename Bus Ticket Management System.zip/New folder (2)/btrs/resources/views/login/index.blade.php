<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>
	<h1>Welcome to Bus Ticket Management System</h1>
	<h2>Sign in</h2>
	<form method="post" >
		@csrf
<!-- 		{{csrf_field()}} -->		
<!-- 		<input type="hidden" name="_token" value="{{csrf_token()}}"> -->

        Usertype:
				<select name="usertype">
				<option value="admin">admin</option>
				<option value="manager">manager</option>
				
				</select> <br>
        
		Username:  <input type="text" required name="uname" > <br>
		Password: <input type="password" required name="password" ><br>
		<input type="submit" name="submit" value="login" ><br> <br>
	</form>

	<h3>{{session('msg')}}</h3>
</body>
</html>