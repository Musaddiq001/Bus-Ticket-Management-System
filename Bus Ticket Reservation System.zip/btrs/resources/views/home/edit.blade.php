<!DOCTYPE HTML>
<html>

<head>
  <title>Managers</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="{{asset('website/style/style.css')}}" />
</head>
<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
		<h1>Welcome Bus Ticket Management System!h1>
          <h2>Bus SUpport Staffs List</h2>
        </div>
      </div>&nbsp
	<div id="menubar">
        <ul id="menu">
<li class="selected"><a href="{{route('home.list')}}">View Managers</a></li>
	<li class="selected"><a href="{{route('home.list1')}}">View Support Staff</a></li>
	<li class="selected"><a href="{{route('home.list2')}}">View Bus Counters</a></li>
	<li class="selected"><a href="{{route('home.list3')}}">View Buses list</a></li>
	<li class="selected"><a href="{{route('home.add')}}">Add new bus</a></li>
	
	<li class="selected"><a href="{{route('logout')}}">Logout</a></li>

        </ul>
      </div>
	  <div id="site_content">
	  
	  <div id="content">

	<form method="post"> >
		{{csrf_field()}}
		<table>
			<tr>
				<td>Id</td>
				<td><input type="text" readonly name="id" value="{{$userId}}"></td>
			</tr>
			<tr>
				<td>Username</td>
				<td><input type="text" name="username" value="{{$username}}"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" name="uname" value="{{$email}}"></td>
			</tr>
				<td>Password</td>
				<td><input type="password" name="password" value="{{$password}}"></td>
			</tr>
			<tr>
				<td>Type</td>
				<td><input type="text" name="type" value="{{$type}}"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Save"></td>
			</tr>
		</table>
			
			</div>
			<div id="sidebar">
    
  <h3 style="color: red;">@foreach($errors->all() as $err)
		{{$err}} <br>
	@endforeach </h3>
	</div>
    </div>
		</form>
		</body>

</body>
</html>