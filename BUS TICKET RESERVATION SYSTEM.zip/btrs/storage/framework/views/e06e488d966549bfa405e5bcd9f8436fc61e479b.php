<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
</head>
<body>	

	<h1>Welcome Btms!</h1>&nbsp

	<a href="<?php echo e(route('home.list')); ?>">View Managers</a> |
	<a href="<?php echo e(route('home.list1')); ?>">View Support Staff</a> |
	<a href="<?php echo e(route('home.list2')); ?>">View Bus Counters</a> |
	<a href="<?php echo e(route('home.list3')); ?>">View Buses list</a> |
	<a href="<?php echo e(route('home.add')); ?>">Add new bus</a> |
	
	<a href="/logout">Logout</a> 

</body>
</html><?php /**PATH C:\xampp\htdocs\aaaa\btrs\resources\views/home/index.blade.php ENDPATH**/ ?>